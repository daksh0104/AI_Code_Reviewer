const express = require('express');
const aiRoute = require('./routes/ai.routes')
const cors = require('cors')
const app = express()

app.get("/", (req, res) => {
    res.send("Hello World")
})

app.use(express.json())
app.use(express.urlencoded({ extended: true }))
app.use(cors())

app.use('/ai', aiRoute)

module.exports = app
